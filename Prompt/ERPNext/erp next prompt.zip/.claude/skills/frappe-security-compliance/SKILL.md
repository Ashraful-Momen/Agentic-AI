---
name: frappe-security-compliance
description: >
  Use when implementing security controls, hardening Frappe/ERPNext applications,
  or reviewing code for vulnerabilities. Covers SQL injection prevention, XSS
  protection, CSRF defenses, authentication hardening, authorization/permission
  enforcement, rate limiting, input validation, file upload security, sensitive
  data exposure prevention, and security logging for Frappe v14/v15/v16.
  Prevents OWASP Top 10 vulnerabilities, ASVS Level 3 compliance gaps, and
  common Frappe-specific security pitfalls. Keywords: security, SQL injection,
  XSS, CSRF, authentication, authorization, rate limiting, input validation,
  file upload, sensitive data, OWASP, ASVS, vulnerability, hardening, secure.
license: MIT
compatibility: "Claude Code, Claude.ai Projects, Claude API. Frappe v14-v16. ASVS Level 3."
metadata:
  author: Unisoft-System-Ltd
  version: "1.0"
  based_on: "OWASP ASVS 4.0.3 Level 3, Frappe Framework Security Model"
---

# Frappe Security & Compliance

> Deterministic security patterns for Frappe/ERPNext v14–v16. Covers all 10 security analysis areas required by the SJIBL ERP security standards.

---

## Decision Tree

```
Security concern?
├── SQL Injection risk? → §1 — Query Security
├── XSS in templates/client scripts? → §2 — XSS Prevention
├── CSRF on custom endpoints? → §3 — CSRF Protection
├── Authentication design? → §4 — Authentication
├── Authorization/permission bypass? → §5 — Authorization
├── API abuse / brute force? → §6 — Rate Limiting
├── Malformed/malicious input? → §7 — Input Validation
├── File upload attack surface? → §8 — File Upload Security
├── Secrets in code/logs/errors? → §9 — Sensitive Data
└── Audit trail needed? → §10 — Security Logging
```

---

## §1 — Query Security (SQL Injection)

### Mandatory Rules

| Rule | Correct | Wrong |
|------|---------|-------|
| Use Frappe QB for dynamic queries | `frappe.qb.from_("tabDoc").select("*").where(...)` | String formatting into SQL |
| Use `frappe.db.sql()` with params | `frappe.db.sql("SELECT * FROM `tabDoc` WHERE name=%s", [name])` | `frappe.db.sql(f"SELECT * FROM `tabDoc` WHERE name='{name}'")` |
| Never f-string/format into SQL | Parametrized only | `f"WHERE name='{user_input}'"` |
| Scope-check every `.sql()` in custom apps | Add `AND company = %(company)s` filter | No scope filter on custom SQL |

### Parameterized Queries — Correct Patterns

```python
# ✅ Pattern 1: frappe.db.sql with tuple params
frappe.db.sql("""
    SELECT name, grand_total
    FROM `tabSales Invoice`
    WHERE company = %s AND docstatus = %s
""", (company, 1))

# ✅ Pattern 2: frappe.db.sql with dict params
frappe.db.sql("""
    SELECT name, grand_total
    FROM `tabSales Invoice`
    WHERE company = %(company)s AND posting_date >= %(from_date)s
""", {"company": company, "from_date": from_date})

# ✅ Pattern 3: Frappe Query Builder (v14+)
from frappe.qb import Order
inv = frappe.qb.DocType("Sales Invoice")
query = (
    frappe.qb.from_(inv)
    .select(inv.name, inv.grand_total)
    .where((inv.company == company) & (inv.docstatus == 1))
    .orderby(inv.posting_date, order=Order.desc)
)
results = query.run(as_dict=True)
```

### Common Pitfall — Dynamic Table/Column/Group BY Names

```python
# ❌ NEVER do this — table/column names from user input
frappe.db.sql(f"SELECT * FROM `tab{table_name}` WHERE status='Open'")

# ✅ Whitelist approach
ALLOWED_TABLES = {"Sales Invoice", "Purchase Invoice", "Journal Entry"}
if table_name not in ALLOWED_TABLES:
    frappe.throw("Invalid table", frappe.PermissionError)
frappe.db.sql("SELECT * FROM `tab{}` WHERE status=%s".format(table_name), ("Open",))

# ✅ For ORDER BY / GROUP BY — whitelist column names
ALLOWED_SORT_COLUMNS = {"posting_date", "grand_total", "name"}
if sort_column not in ALLOWED_SORT_COLUMNS:
    sort_column = "name"  # safe default
# Frappe QB for the rest, then sort in Python
```

### Scope Condition — Mandatory for Custom SQL

```python
# Every frappe.db.sql() in a custom app MUST include scope filtering:
def get_invoices(company):
    # ✅ Scoped query — only returns records for the authorized company
    return frappe.db.sql("""
        SELECT name, grand_total, posting_date
        FROM `tabSales Invoice`
        WHERE company = %(company)s
          AND docstatus = 1
        ORDER BY posting_date DESC
    """, {"company": company}, as_dict=True)
```

---

## §2 — XSS Prevention

### Jinja Templates (Print Formats, Email Templates)

```jinja
<!-- ❌ UNSAFE — raw user data in HTML -->
<div>{{ doc.customer_name }}</div>
<div>{{ doc.terms }}</div>

<!-- ✅ SAFE — Jinja auto-escapes {{ }} in Frappe -->
<div>{{ doc.customer_name }}</div>  <!-- auto-escaped -->

<!-- ⚠️ SAFE but verify — frappe.format strips HTML by default -->
<div>{{ frappe.format(doc.grand_total, {"fieldtype": "Currency"}) }}</div>

<!-- ❌ NEVER use |safe on user data -->
{{ doc.terms | safe }}  <!-- INJECTION RISK -->

<!-- ✅ Only use |safe on trusted, sanitized content -->
{{ trusted_html_content | safe }}  <!-- must be sanitized before storage -->
```

### Client Scripts (JavaScript)

```javascript
// ❌ UNSAFE — raw HTML injection
frm.set_value('description', user_input);
$(element).html(user_input);  // jQuery HTML injection

// ✅ SAFE — set_value auto-escapes in form fields
frm.set_value('description', user_input);

// ✅ SAFE — use text(), not html(), for user data
$(element).text(user_input);

// ✅ Pattern: sanitize before storing HTML content
// Server-side (Python):
from bs4 import BeautifulSoup
def sanitize_html(html_content):
    allowed_tags = ['p', 'br', 'strong', 'em', 'ul', 'ol', 'li', 'a']
    allowed_attrs = {'a': ['href', 'title']}
    soup = BeautifulSoup(html_content, 'html.parser')
    for tag in soup.find_all():
        if tag.name not in allowed_tags:
            tag.unwrap()
        else:
            tag.attrs = {k: v for k, v in tag.attrs.items() if k in allowed_attrs.get(tag.name, [])}
    return str(soup)
```

---

## §3 — CSRF Protection

### Frappe's Built-in CSRF

Frappe automatically provides CSRF tokens on all form submissions and AJAX calls made through the Frappe JS API (`frappe.call`, `frappe.db.get_value`, etc.). Custom endpoints need explicit configuration.

```python
# ✅ Frappe JS API — CSRF token included automatically
frappe.call({
    method: "my_app.api.create_invoice",
    args: { customer: "ABC Corp" },
    callback: function(r) { ... }
});

# ✅ Server-side whitelisted method — CSRF checked by default
@frappe.whitelist()
def my_endpoint():
    # CSRF token is verified automatically for POST/PUT/DELETE
    pass

# ⚠️ CSRF Exempt — ONLY for webhook receivers / public APIs
@frappe.whitelist(allow_guest=True)
def webhook_receiver():
    # Must implement alternative verification:
    # - HMAC signature verification
    # - IP whitelist check
    # - Shared secret validation
    pass
```

### Custom API CSRF Verification

```python
# For custom REST endpoints outside Frappe's router:
from frappe.handler import execute_cmd
from frappe import csrf

# Frappe checks CSRF token in:
# - Header: X-Frappe-CSRF-Token
# - Cookie: sid (session ID)
# - Request body: csrf_token parameter
```

---

## §4 — Authentication

### Authentication Methods — Security Ranking

| Method | Security Level | Use For | Risk |
|--------|---------------|---------|------|
| Session + CSRF | HIGH | Browser-based Desk UI | Session hijacking if no HTTPS |
| Token (api_key:api_secret) | HIGH | Server-to-server, automation | Secret exposure if logged |
| OAuth 2.0 (Connected App) | HIGH | Third-party integrations | Redirect URI validation critical |
| Password-based (Basic Auth) | LOW | Never in production | Credentials in every request |
| Guest (allow_guest=True) | NONE | Public web forms only | No authentication at all |

### Token Security

```python
# ✅ Generate and store securely
bench execute frappe.core.doctype.user.user.generate_keys --args ['user@example.com']

# ✅ Use environment variables, never hardcode
import os
API_KEY = os.environ.get("ERP_API_KEY")
API_SECRET = os.environ.get("ERP_API_SECRET")

# ✅ Rotate keys on compromise or schedule
# User list → Open user → API Access → Regenerate Keys

# ❌ NEVER log or display API secrets
frappe.log_error("Auth failed", frappe.get_traceback())  # traceback may contain secrets!
```

### Guest Endpoint Hardening

```python
@frappe.whitelist(allow_guest=True)
def public_form_submit(data):
    # 1. Validate input strictly
    # 2. Rate limit (see §6)
    # 3. CAPTCHA verification for human users
    # 4. Never return sensitive data
    # 5. Log all submissions for audit
    # 6. Set explicit permission boundaries
    pass
```

---

## §5 — Authorization

> See `frappe-core-permissions` skill for complete permission system reference. This section covers authorization verification patterns.

### Server-Side Authorization Checks

```python
# ✅ Pattern 1: Check before action
if not frappe.has_permission(doctype="Sales Invoice", doc=doc, ptype="submit"):
    frappe.throw("Not permitted to submit this invoice", frappe.PermissionError)

# ✅ Pattern 2: Raise on denial (shorter)
doc.check_permission("submit")  # throws PermissionError on denial

# ✅ Pattern 3: Whitelisted method — NEVER trust client role assertions
@frappe.whitelist()
def approve_invoice(invoice_name):
    # ALWAYS re-verify server-side
    doc = frappe.get_doc("Sales Invoice", invoice_name)
    doc.check_permission("submit")
    # ... proceed with approval

# ❌ NEVER: No permission check on whitelisted method
@frappe.whitelist()
def dangerous_action(docname):
    doc = frappe.get_doc("Sales Invoice", docname)
    doc.submit()  # NO PERMISSION CHECK — REJECTED AT REVIEW

# ✅ Permission check with throw=True
@frappe.whitelist()
def safe_action(docname):
    if not frappe.has_permission("Sales Invoice", "submit", throw=True):
        return  # throw=True already raised the error
    doc = frappe.get_doc("Sales Invoice", docname)
    doc.submit()
```

### Fail-Closed Principle

```python
# ✅ Every error/exception path MUST deny access
try:
    result = external_service.check_approval(doc)
except TimeoutError:
    # FAIL CLOSED — timeout means NO, not YES
    frappe.throw("Approval service unavailable. Cannot proceed.", frappe.ValidationError)
except Exception as e:
    # FAIL CLOSED — any unexpected error means NO
    frappe.log_error(title="Approval check failed", message=frappe.get_traceback())
    frappe.throw("Approval verification failed. Access denied.", frappe.PermissionError)
```

---

## §6 — Rate Limiting

### Frappe's Built-in Rate Limiting

```python
# Configure in common_site_config.json:
{
    "rate_limit": {
        "window": 600,      // 10 minutes in seconds
        "limit": 500        // max 500 requests per window per IP
    }
}
```

### Per-User / Per-Endpoint Rate Limiting

```python
# ✅ Custom rate limiter using Frappe cache
from frappe.utils import now_datetime
import hashlib

def check_rate_limit(user, action, max_requests=10, window_seconds=60):
    """
    Rate limit a specific action per user.
    Returns True if allowed, raises frappe.ValidationError if exceeded.
    """
    cache_key = f"rate_limit:{hashlib.sha256(f'{user}:{action}'.encode()).hexdigest()}"
    attempts = frappe.cache().get(cache_key) or []

    # Purge old entries outside window
    cutoff = now_datetime().timestamp() - window_seconds
    attempts = [t for t in attempts if t > cutoff]

    if len(attempts) >= max_requests:
        frappe.throw(
            f"Rate limit exceeded. Max {max_requests} requests per {window_seconds}s.",
            frappe.ValidationError
        )

    attempts.append(now_datetime().timestamp())
    frappe.cache().set(cache_key, attempts, expires=window_seconds)
    return True

# Usage in whitelisted method:
@frappe.whitelist(allow_guest=True)
def public_api_endpoint():
    check_rate_limit(
        user=frappe.session.user,
        action="public_api",
        max_requests=30,
        window_seconds=60
    )
    # ... proceed
```

---

## §7 — Input Validation

### Server-Side Validation (Mandatory)

```python
import re
from frappe.utils import validate_email_address

# ✅ Pattern: Validate all inputs at the boundary
@frappe.whitelist()
def create_vendor(vendor_data):
    # Type validation
    if not isinstance(vendor_data.get("vendor_name"), str):
        frappe.throw("vendor_name must be a string")

    # Length validation
    if len(vendor_data.get("vendor_name", "")) > 140:
        frappe.throw("vendor_name exceeds 140 characters")

    # Format validation
    if vendor_data.get("email") and not validate_email_address(vendor_data["email"]):
        frappe.throw(f"Invalid email: {vendor_data['email']}")

    # Pattern validation (e.g., BIN, NID, e-TIN)
    if vendor_data.get("bin") and not re.match(r'^\d{9,13}$', vendor_data["bin"]):
        frappe.throw("BIN must be 9-13 digits")

    # Enum/choice validation
    VALID_STATUSES = {"Active", "Inactive", "Blacklisted"}
    if vendor_data.get("status") not in VALID_STATUSES:
        frappe.throw(f"Status must be one of: {', '.join(VALID_STATUSES)}")

    # Monetary validation (never float)
    from decimal import Decimal, InvalidOperation
    try:
        amount = Decimal(str(vendor_data.get("credit_limit", "0")))
    except (InvalidOperation, ValueError):
        frappe.throw("credit_limit must be a valid decimal number")

    # Range validation
    if amount < 0:
        frappe.throw("credit_limit cannot be negative")

    # ... proceed with validated data
```

### Common Frappe Validation Utilities

| Utility | Use For |
|---------|---------|
| `frappe.utils.validate_email_address(email)` | Email format validation |
| `frappe.utils.validate_phone_number(phone, throw=False)` | Phone number validation |
| `frappe.utils.cstr(value)` | Safe string coercion |
| `frappe.utils.cint(value)` | Safe integer coercion |
| `frappe.utils.flt(value, precision)` | Safe float coercion (for non-monetary) |
| `Decimal(str(value))` | Monetary values (mandatory) |
| `frappe.utils.data.now_datetime()` | Current datetime |
| `len(value)` with explicit max check | String/binary length |
| `re.match(pattern, value)` | Custom format validation |

---

## §8 — File Upload Security

```python
# ✅ Validate file uploads server-side
ALLOWED_EXTENSIONS = {"pdf", "jpg", "jpeg", "png", "doc", "docx", "xls", "xlsx"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

def validate_upload(file_data, file_name):
    # Extension validation
    ext = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
    if ext not in ALLOWED_EXTENSIONS:
        frappe.throw(f"File type .{ext} not allowed. Allowed: {', '.join(ALLOWED_EXTENSIONS)}")

    # Size validation
    if len(file_data) > MAX_FILE_SIZE:
        frappe.throw(f"File exceeds maximum size of {MAX_FILE_SIZE // (1024*1024)} MB")

    # MIME type validation (check actual content, not just extension)
    import mimetypes
    detected_mime = mimetypes.guess_type(file_name)[0]
    ALLOWED_MIMES = {
        "application/pdf", "image/jpeg", "image/png",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }
    if detected_mime not in ALLOWED_MIMES:
        frappe.throw(f"File type {detected_mime} not permitted")

    # Path traversal prevention
    if ".." in file_name or file_name.startswith("/"):
        frappe.throw("Invalid file name")

    return ext

# ✅ Use private files for sensitive documents
# Attach as: doc.attachments (private = True)
# Public files go to: frappe-bench/sites/<site>/public/files/
# Private files go to: frappe-bench/sites/<site>/private/files/

# ❌ NEVER save user uploads to public/ without validation
```

---

## §9 — Sensitive Data Exposure

### Secrets Management

```python
# ❌ NEVER — Secrets in code
API_KEY = "abc123secret"  # REJECTED by gitleaks pre-commit
# ❌ NEVER — Secrets in logs
frappe.log_error(f"Auth failed with key {api_secret}", ...)
# ❌ NEVER — Secrets in error messages
frappe.throw(f"Invalid token: {token}")

# ✅ Use environment variables
import os
API_KEY = os.environ.get("SJIBL_API_KEY")

# ✅ Use Frappe password fields (encrypted at rest)
# DocType field: fieldtype="Password"

# ✅ Log references, not secrets
frappe.log_error(
    title="API Authentication Failed",
    message=f"User: {frappe.session.user}, IP: {frappe.local.request_ip}"
)

# ✅ Mask secrets in error output
def safe_error_message(error_detail):
    # Redact potential secrets before returning to client
    REDACT_PATTERNS = [
        (r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer [REDACTED]'),
        (r'token\s+[A-Za-z0-9]+:', 'token [REDACTED]:'),
        (r'password[=:]\s*[^\s,;]+', 'password=[REDACTED]'),
    ]
    for pattern, replacement in REDACT_PATTERNS:
        error_detail = re.sub(pattern, replacement, str(error_detail), flags=re.IGNORECASE)
    return error_detail
```

### Error Message Discipline

```python
# ❌ NEVER expose internals to users
frappe.throw(f"DB connection failed at 10.0.1.5:3306 — root:password123")
frappe.throw(f"Query error: {sql_query}")  # leaks schema
frappe.throw(f"File not found: /etc/frappe/secrets.json")

# ✅ User-facing errors: what happened, why, what to do
frappe.throw(
    "Unable to process your request at this time. "
    "Please try again or contact support if the issue persists."
)

# ✅ Log the technical detail separately
frappe.log_error(
    title="DB Connection Failed",
    message=frappe.get_traceback()
)
```

### Data Classification

| Classification | Storage | Transmission | Examples |
|---------------|---------|--------------|----------|
| Public | Public files | HTTP (OK) | Product images, logos |
| Internal | Private files | HTTPS | Reports, business docs |
| Confidential | Private files + encrypted | HTTPS + TLS | Contracts, financial data |
| Restricted | Password field / vault | HTTPS + encrypted payload | API keys, passwords, NID, BIN |

---

## §10 — Security Logging

### What to Log

```python
# ✅ Log security-relevant events
def log_security_event(event_type, details):
    """
    Log security events for audit trail.
    event_type: 'auth_failure', 'permission_denied', 'rate_limit_exceeded',
                'file_upload_blocked', 'input_validation_failure', 'suspicious_activity'
    """
    frappe.log_error(
        title=f"SECURITY: {event_type}",
        message=f"User: {frappe.session.user}\n"
                f"IP: {frappe.local.request_ip}\n"
                f"Timestamp: {frappe.utils.now_datetime()}\n"
                f"Details: {details}"
    )

# Events that MUST be logged:
# 1. Authentication failures (wrong password, invalid token)
# 2. Permission denied events
# 3. Rate limit exceeded
# 4. File upload blocked (wrong type, too large)
# 5. Input validation failures (potential injection attempts)
# 6. Admin actions (role changes, permission changes)
# 7. Data export/download of sensitive records
```

### Security Checklist (Pre-Deployment)

- [ ] All `frappe.db.sql()` in custom apps use parameterized queries
- [ ] All `@frappe.whitelist()` methods have server-side permission checks
- [ ] No secrets in code, config, env vars logged to error output
- [ ] File upload endpoints validate extension, size, and MIME type
- [ ] Guest-accessible endpoints have rate limiting
- [ ] Jinja templates never use `|safe` on user-supplied data
- [ ] Error messages do not expose paths, queries, versions, or credentials
- [ ] HTTPS enforced in production (Nginx/SSL configured)
- [ ] API keys/secrets stored in environment variables, not code
- [ ] gitleaks pre-commit hook active (runs in CI pipeline)

---

## References

- OWASP ASVS 4.0.3: https://owasp.org/www-project-application-security-verification-standard/
- Frappe Permissions: `frappe-core-permissions` skill
- Frappe API Auth: `frappe-core-api/references/authentication-methods.md`
- Frappe Deployment: `frappe-ops-deployment` skill
- Frappe File Handling: `frappe-core-files` skill
- Frappe Logging: `frappe-core-logging` skill
- CICD Security Scans: `frappe-testing-cicd` skill
