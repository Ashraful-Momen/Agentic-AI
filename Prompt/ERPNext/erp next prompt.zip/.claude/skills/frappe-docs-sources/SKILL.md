---
name: frappe-docs-sources
description: >
  Use when you need to verify APIs, check official documentation, or determine
  the authoritative source for any Frappe/ERPNext question. Encodes the complete
  documentation URL catalog and the source-of-truth priority hierarchy (P1-P10).
  Must be consulted BEFORE using pretrained knowledge — official documentation
  always wins when they conflict. Covers ERPNext docs, Frappe Framework docs,
  GitHub repositories, release notes, migration guides, and bench documentation
  for v14/v15/v16. Keywords: documentation, docs, source of truth, official
  docs, verify API, ERPNext docs, Frappe docs, GitHub, release notes, migration.
license: MIT
compatibility: "Claude Code, Claude.ai Projects, Claude API. Frappe v14-v16."
metadata:
  author: Unisoft-System-Ltd
  version: "1.0"
  based_on: "SJIBL ERP System Prompt — Source of Truth Priority"
---

# Frappe Documentation Sources & Truth Hierarchy

> The authoritative catalog of official documentation URLs and the mandatory
> source-of-truth priority order. **Never allow pretrained knowledge to override
> these sources.**

---

## Source of Truth Priority (P1 → P10)

When answering ANY ERPNext/Frappe question, use information in this exact order.
If a higher-priority source conflicts with a lower one, the higher one wins.
**If your pretrained knowledge conflicts with any P1–P9 source, the source wins.**

| Priority | Source | Description |
|----------|--------|-------------|
| **P1** | [ERPNext Documentation](https://docs.erpnext.com) | Latest official ERPNext docs |
| **P2** | [Frappe Framework Docs](https://docs.frappe.io/framework) | Latest official Frappe Framework docs |
| **P3** | [ERPNext GitHub](https://github.com/frappe/erpnext) | Official ERPNext source code |
| **P4** | [Frappe Framework GitHub](https://github.com/frappe/frappe) | Official Frappe source code |
| **P5** | [ERPNext Releases](https://github.com/frappe/erpnext/releases) | Official release notes, changelogs |
| **P6** | [Frappe Releases](https://github.com/frappe/frappe/releases) | Framework changelogs, breaking changes |
| **P7** | [Bench Documentation](https://docs.frappe.io/framework/user/en/bench) | Official bench CLI reference |
| **P8** | **This project's source code** | `frappe-bench/apps/sjibl_*` |
| **P9** | **This project's database schema** | MariaDB via `bench console` |
| **P10** | Pretrained knowledge | **Last resort — never primary** |

---

## Official Documentation URLs

### Primary

| Resource | URL |
|----------|-----|
| ERPNext Documentation | https://docs.erpnext.com |
| Frappe Framework Documentation | https://docs.frappe.io/framework |
| Frappe Developer Documentation | https://docs.frappe.io/framework/user/en |
| ERPNext User Manual | https://docs.erpnext.com/docs/user/manual |
| Frappe API Documentation | https://docs.frappe.io/framework/user/en/api |
| Bench Documentation | https://docs.frappe.io/framework/user/en/bench |
| Frappe Migration Guide | https://docs.frappe.io/framework/user/en/migration |

### Source Code & Releases

| Resource | URL |
|----------|-----|
| ERPNext GitHub Repository | https://github.com/frappe/erpnext |
| Frappe Framework GitHub Repository | https://github.com/frappe/frappe |
| ERPNext Releases (changelog) | https://github.com/frappe/erpnext/releases |
| Frappe Releases (changelog) | https://github.com/frappe/frappe/releases |
| ERPNext Wiki | https://github.com/frappe/erpnext/wiki |

### Marketplace & Community

| Resource | URL |
|----------|-----|
| Frappe Cloud Marketplace | https://frappecloud.com/marketplace |
| Frappe Community Forum | https://discuss.frappe.io |

---

## Documentation-First Policy

### Mandatory Rules

1. **Read documentation first** — before writing any code, before answering any question, before suggesting any approach.
2. **Verify API existence** — check that every method, parameter, hook, and decorator you use actually exists in the declared Frappe version.
3. **Verify DocType schemas** — check field names, fieldtypes, and constraints against the official source or the project's actual database.
4. **Verify version compatibility** — APIs change between v14, v15, and v16. A method that exists in v16 may not exist in v14.
5. **Never answer from memory** when documentation/web/repository access is available.
6. **Documentation wins** — if docs conflict with memory, docs are correct. If docs changed after training cutoff, follow current docs.

### When Documentation Access is Unavailable

If web access, MCP tools, GitHub access, or browser tools are unavailable:
- **Explicitly state the limitation** to the user
- **Request the relevant documentation** or source files
- **Never fabricate** APIs, features, or methods to fill the gap

---

## Verification Checklist

Before using any Frappe/ERPNext API, method, or pattern, verify:

- [ ] Does this API exist in the target Frappe version (v14/v15/v16)?
- [ ] Are the parameters correct (name, type, order, defaults)?
- [ ] Is this method deprecated or replaced in newer versions?
- [ ] Does this hook actually fire in the expected order?
- [ ] Does this DocType have the fields I'm referencing?
- [ ] Are the permission rules sufficient for this operation?
- [ ] Is this REST API endpoint available in the target version?

### How to Verify (in priority order)

1. **WebFetch** the official documentation URL
2. **WebSearch** for the specific API + version
3. **Grep/Bash** search this project's source for usage examples
4. **Read** the Frappe/ERPNext source in `frappe-bench/apps/frappe` or `frappe-bench/apps/erpnext`
5. **bench console** — test the API live against the development database

---

## Version-Specific Notes

### Frappe v16 (current for this project)
- Data Masking on fields (`mask` property) — new in v16
- esbuild replaces build.json for frontend assets (migrated in v15)
- Frappe QB is the recommended query builder

### Common Breaking Changes (v14 → v15 → v16)
- `build.json` → esbuild (v15+)
- `frappe.msgprint` → `frappe.msgprint` (still valid) but prefer `frappe.throw` for errors
- Scheduler events syntax unchanged but background job internals evolved
- Several `frappe.utils` functions renamed or relocated — always verify

---

## Related Skills

- `frappe-agent-debugger` — debug using bench console
- `frappe-agent-validator` — validate code against best practices
- `frappe-agent-migrator` — detect breaking changes during upgrades
- `frappe-ops-upgrades` — version upgrade procedures
- `frappe-syntax-*` — API syntax reference for each area
