# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## Project Overview

ERP system for Shahjalal Islami Bank PLC (SJIBL), an Islamic Shariah-compliant bank in Bangladesh. Built by Unisoft System Ltd's in-house team on **ERPNext v16 + Frappe Framework v16**, Python 3.14, Node 24, MariaDB LTS. Covers source-to-pay procurement, facilities, and Shariah governance. 21 modules (M01–M21), ~35% custom code across 7 custom Frappe apps.

## Skills Directory — Always Read First

Before starting **any work** on this project, consult the skills at `.claude/skills/`. This project uses the **Frappe Claude Skill Package v3.2** (61 skills across 7 categories, covering Frappe/ERPNext v14–v16). Skills are loaded on-demand via Claude Code's skill system — they activate automatically when your task matches a skill's description.

**Always load these skills:**
- `code-style` — project code conventions (always, for any code change)
- `technical-writing` — commit messages, docs, PR descriptions

### Skill Routing — Decision Tree

Use this decision tree to find the right skill(s). The full catalog is at `.claude/skills/INDEX.md`.

| What are you doing? | Load these skills |
|---|---|
| **Any code change** | `code-style` (always) |
| **Form behavior / client-side UI** | `frappe-syntax-clientscripts` + `frappe-impl-clientscripts` + `frappe-errors-clientscripts` |
| **DocType controllers / server logic** | `frappe-syntax-controllers` + `frappe-impl-controllers` + `frappe-errors-controllers` |
| **Quick server logic (no app)** | `frappe-syntax-serverscripts` + `frappe-impl-serverscripts` + `frappe-errors-serverscripts` |
| **API endpoints / whitelisted methods** | `frappe-syntax-whitelisted` + `frappe-impl-whitelisted` + `frappe-core-api` + `frappe-errors-api` |
| **DocType schema / fields** | `frappe-syntax-doctypes` |
| **Custom app scaffolding** | `frappe-syntax-customapp` + `frappe-impl-customapp` + `frappe-ops-app-lifecycle` |
| **Print formats / PDF / email templates** | `frappe-syntax-print` + `frappe-syntax-jinja` + `frappe-impl-jinja` |
| **Reports / dashboards / charts** | `frappe-syntax-reports` + `frappe-impl-reports` + `frappe-syntax-query-builder` |
| **Permissions / role setup** | `frappe-core-permissions` + `frappe-errors-permissions` |
| **Workflows / approvals** | `frappe-core-workflow` + `frappe-impl-workflow` |
| **Hooks / events / scheduler** | `frappe-syntax-hooks` + `frappe-syntax-hooks-events` + `frappe-impl-hooks` + `frappe-errors-hooks` |
| **Background jobs / scheduler** | `frappe-syntax-scheduler` + `frappe-impl-scheduler` |
| **Database queries / qb** | `frappe-core-database` + `frappe-syntax-query-builder` + `frappe-errors-database` |
| **File uploads / attachments / S3** | `frappe-core-files` |
| **Caching / Redis** | `frappe-core-cache` |
| **Notifications / alerts / emails** | `frappe-core-notifications` |
| **Logging / error tracking** | `frappe-core-logging` |
| **Search / FTS** | `frappe-core-search` |
| **Translation / i18n** | `frappe-core-translation` |
| **Utility functions** | `frappe-core-utils` |
| **Web forms / portals / website** | `frappe-impl-website` |
| **Custom UI components / dialogs** | `frappe-impl-ui-components` |
| **Workspace pages** | `frappe-impl-workspace` |
| **Integrations / OAuth / webhooks** | `frappe-impl-integrations` |
| **Testing (unit/integration)** | `frappe-testing-unit` |
| **CI/CD / linting / security scans** | `frappe-testing-cicd` |
| **Bench operations / multi-tenancy** | `frappe-ops-bench` |
| **Production deployment** | `frappe-ops-deployment` + `frappe-ops-performance` + `frappe-ops-backup` |
| **Version upgrades (v14→v15→v16)** | `frappe-ops-upgrades` + `frappe-agent-migrator` |
| **Asset building / SCSS / esbuild** | `frappe-ops-frontend-build` |
| **Debugging errors** | `frappe-agent-debugger` + matching `frappe-errors-*` skill |
| **Code review / validation** | `frappe-agent-validator` + `quality-code-review` |
| **Architecture design** | `frappe-agent-architect` |
| **Unclear requirements** | `frappe-agent-interpreter` |
| **Docker dev environment** | `frappe-manager` |
| **Security review / vulnerability hardening** | `frappe-security-compliance` + `frappe-core-permissions` |
| **Verifying APIs / checking official docs** | `frappe-docs-sources` |
| **UI/UX design, layout** | `ui-design` |
| **Project-specific code style** | `code-style` |
| **Technical writing, docs, commits** | `technical-writing` |

**Key principle:** For any Frappe task, combine the matching `syntax/` (reference), `impl/` (how-to), and `errors/` (troubleshooting) skill. Most tasks need 2–4 skills working together.

**If unsure where to start, invoke `frappe-agent-interpreter`** — it will analyze your request and recommend the right skills.

---

## Documentation-First Policy

**Never allow pretrained knowledge to override official documentation.** Before writing any code, answering any question, or suggesting any approach:

1. **Read documentation first** — use `frappe-docs-sources` for the complete URL catalog and P1–P10 source-of-truth priority hierarchy
2. **Verify API existence** — check every method, parameter, hook, and decorator against the declared Frappe v16 documentation
3. **Verify version compatibility** — APIs change between v14, v15, and v16
4. **If web/repository access is unavailable**, explicitly state the limitation and request the relevant source files — never fabricate

**When documentation conflicts with pretrained knowledge, documentation wins. Always.**

---

## Mandatory Behavioral Rules

These rules are non-negotiable. Every response, every code change, every suggestion must follow them.

1. **Never guess.** If evidence is insufficient, ask for what's needed.
2. **Never hallucinate.** Do not invent APIs, features, hooks, DocTypes, or methods.
3. **Never fabricate.** If you don't know, say so. If you can't verify, say so.
4. **Always verify.** Check documentation, search the repository, read the source before writing code.
5. **Always explain WHY.** Every recommendation must include reasoning and evidence.
6. **Find the REAL root cause.** Never stop at the first error — continue until the underlying cause is identified.
7. **Generate the MINIMUM required code changes.** Smallest possible patch that fixes the root cause without regressions.
8. **Fail closed.** Every error/exception/timeout must deny access, block the action, or halt the workflow — never proceed past a failure.
9. **Prefer correctness over speed.** A slow correct answer is infinitely better than a fast wrong one.

---

## When Information Is Missing

If there is not enough evidence to proceed confidently, **do not guess**. Instead, ask for:

- Complete traceback (full stack, not just the last frame)
- Relevant source files (the files actually involved, not guesses)
- `hooks.py` — all apps involved
- `apps.txt` — installed app list
- `site_config.json` / `common_site_config.json`
- `bench version` / ERPNext version / Frappe version / Python version / Database version
- Relevant logs (`frappe-bench/logs/`, `frappe.log_error` output)
- Bench commands executed and their output
- Expected behaviour vs. actual behaviour

---

## Output Format — Bug Analysis & Code Changes

When debugging, analyzing bugs, or proposing code changes, use this structured format:

```
# Problem Summary
(What happened, what was expected)

---

# Root Cause
(The underlying cause, not just the symptom)

---

# Evidence
- Documentation: (relevant official docs consulted)
- Repository files: (files read in the upstream repos)
- Project files: (files read in this project)
- Logs: (relevant log excerpts)
- Traceback: (key frames)

---

# Affected Files
(List every file that needs to change)

---

# Recommended Solution
(Ranked options if multiple exist, with rationale)

---

# Code Changes
(Minimal diff — only the lines that must change)

---

# Why This Works
(Explanation of the mechanism)

---

# Risks
(What could go wrong with this approach)

---

# Regression Risks
(What existing behaviour could break)

---

# Testing Checklist
(Specific test cases that verify the fix)

---

# Prevention
(How to prevent this class of bug in the future)
```

## Commands

### Start/Stop

```bash
# Start everything (Docker deps + dev server)
./start.sh

# Or manually:
colima start --cpu 4 --memory 8
docker compose up -d                    # MariaDB, PostgreSQL, Valkey, Mailpit
cd frappe-bench && bench start          # Dev server on port 8002

# Stop
docker compose down
colima stop
```

### Development

```bash
# Console
bench --site sjibl-erp.local console

# After schema changes
bench --site sjibl-erp.local migrate

# Build JS/CSS assets
bench build

# Create a new custom app
bench new-app sjibl_<name> --site sjibl-erp.local

# Get a new Frappe app from remote
bench get-app --branch version-16 <app-name>

# Install an app on the site
bench --site sjibl-erp.local install-app <app-name>

# Export configuration to fixtures (SR-2: configuration as code)
bench --site sjibl-erp.local export-fixtures
```

### Testing

```bash
# Run all tests for a specific app
bench --site sjibl-erp.local run-tests --app sjibl_core

# Run a specific test module
bench --site sjibl-erp.local run-tests --app sjibl_core --module sjibl_core.tests.test_audit

# Run tests with coverage
bench --site sjibl-erp.local run-tests --app sjibl_core --coverage

# When debugging: start without threading/reload so breakpoints work
bench start --nothreading --noreload
```

### Lint & Format

```bash
ruff check .                    # Python lint
ruff format .                   # Python format
npx eslint .                    # JS lint
npx prettier --check .          # JS format
gitleaks detect -v              # Secret scanning (runs in pre-commit + CI)
```

### Database Access

```bash
# MariaDB (primary application DB)
mariadb -h 127.0.0.1 -P 3307 -u root -psjibl_root_2026

# PostgreSQL (append-only audit sink)
psql -h 127.0.0.1 -p 5436 -U sjibl_audit_user -d sjibl_audit

# Or use phpMyAdmin at http://127.0.0.1:8082 (root / sjibl_root_2026)
```

## Architecture

### Four-Layer Reuse Discipline (TS-PREM-001)

Every requirement is met by the highest layer that can satisfy it. Custom code is the layer of last resort.

| Layer | What | Example |
|---|---|---|
| L1 — Configure | ERPNext/Frappe native DocTypes, workflows, reports (JSON fixtures, no code) | Material Request → RFQ → PO → Receipt → Invoice |
| L2 — Official apps | Install Frappe ecosystem apps | Frappe HR, Insights, Print Designer, Payments |
| L3 — Marketplace | Community apps, source-reviewed before install | Bangladesh VAT (Mushak), e-sign |
| L4 — Custom app | Built from scratch only when no layer above covers it | Sealed-bid tendering, DoA matrix, Shariah compliance |

**Rule:** A requirement is met by configuration (L1), then by installing an existing app (L2–L3), and only then by writing a custom Frappe app (L4). No requirement is custom-built until proven no higher layer covers it.

### App Dependency Graph (SDD-005)

Dependencies are strictly one-way, enforced at build time. `sjibl_core` is the only shared import — it never imports from another `sjibl_*` app. Circular imports fail the build.

```
sjibl_facilities ─┐
sjibl_cbs ────────┤
sjibl_shariah ────┼──▶ sjibl_doa ──▶ sjibl_core ──▶ erpnext ──▶ frappe
sjibl_auction ────┤                      ▲
sjibl_tender ─────┘                      │
                    sjibl_bn ────────────┘  (applied globally via hook)
```

### The 7 Custom Apps

| App | Purpose | Custom % | Built By |
|---|---|---|---|
| `sjibl_core` | Shared primitives: gapless numbering, idempotency store, audit streamer (PostgreSQL sink), security instruments, effective-dated rule base | — | Dev A (lead) |
| `sjibl_bn` | Bengali data layer: NFC normalization, `match_key`, Bijoy detection, bilingual lakh-crore amounts-in-words | — | Dev A (lead) |
| `sjibl_doa` | Delegation of Authority engine: amount-banded matrix, M-of-N quorum, escalation, SoD blocking, recusal | — | Dev B (lead) |
| `sjibl_tender` | Sealed-bid tendering: AES-256-GCM envelope encryption, HSM key wrapping, two-envelope separation, tamper-evident receipts | 85% | Dev A |
| `sjibl_auction` | e-Auction: anonymous bidding, earnest money as % of bidder's own quote, Socket.IO countdown, close integrity | 90% | Dev A |
| `sjibl_shariah` | Shariah governance: template certification, vendor screening, income purification, Takaful enforcement | 80% | Dev B |
| `sjibl_cbs` | Core Banking System integration: transactional outbox/inbox, idempotent GL posting, CoA sync | — | Dev B |

### Extension-Point Discipline (SDD-003)

Frappe is metadata-driven: one DocType definition generates the DB table, ORM, REST API, permissions, list/form UI, and change history. Only build what isn't generated.

Extension points in order of preference — reaching for a lower row without justification is rejected at review:

1. Custom Field / Property Setter
2. Native Workflow (sequential approvals)
3. Notification / Assignment Rule / Auto Repeat
4. Report Builder / Dashboard / Number Card / Workspace
5. Web Form (vendor-facing forms)
6. Client Script (field-level UI)
7. Server Script ⚠️ (simple validations only — never security or complex logic)
8. New DocType in a custom app
9. `hooks.py` — `doc_events` (cross-cutting behaviour)
10. `hooks.py` — `override_doctype_class` ⚠️ (requires ARB approval)
11. `hooks.py` — `permission_query_conditions` (row-scope)
12. `hooks.py` — `scheduler_events` (time-driven work)
13. `hooks.py` — `override_whitelisted_methods` ⚠️ (requires ARB approval)

**Never:** edit `apps/frappe` or `apps/erpnext` directly. Enforced by pipeline (build fails on any diff in those directories). Extension points are `hooks.py` only.

### Two-Developer Split

The project is divided at **M06 (Purchase Order)**:

| | Developer A | Developer B |
|---|---|---|
| **Domain** | Source-to-Order (before PO) | Receive-to-Pay + Operations (after PO) |
| **Modules** | M02–M06, M11 | M07–M10, M12–M21 |
| **Custom apps** | `sjibl_tender`, `sjibl_auction` | `sjibl_cbs`, `sjibl_shariah` |
| **Effort** | ~45% | ~55% |

Dev A publishes DocType schemas (M04 Vendor, M06 PO). Dev B codes against those schemas — never calls Dev A's custom Python code. Full plan: `documents/2-developer-development-plan.md`.

## Critical Code Standards (from `03-01`)

These are contractual, enforced by code review and/or the CI pipeline:

### Data Handling
- **Monetary values are `Decimal`, never `float`, at every tier.** Serialized as **strings** across every API boundary. JavaScript's `Number` is binary64 — amounts do not round-trip losslessly through JSON numbers. Enforced by pipeline (contract test fails if any monetary value is a JSON number).
- **Rounding mode is explicit** on every division or rate operation. No library default.
- **No physical delete** of business documents. Cancellation is a state transition.
- **Every state transition is a conditional UPDATE** predicated on expected current state. Zero rows affected = concurrency conflict, never blindly retried.
- **Identifiers that look numeric** (BIN, e-TIN, NID, trade licence, account numbers) are **text with leading zeros preserved**.

### Bengali Text (`sjibl_bn`)
- **NFC-normalize at input boundary.** Comparisons, uniqueness, and search use `match_key`. Display and legal output use the NFC value.
- **Never strip ZWJ from a stored value.** It is semantically load-bearing. Removal happens only in the derived `match_key`.
- **Amount-in-words generated in one transaction** from the same stored `Decimal`. Divergence between words and figures is a severity-1 defect. Both English and Bangla (lakh-crore scale). The words field is the legally operative amount under NI Act 1881 s.18.

### Security (ASVS Level 3 for 5 critical paths)
- **Server-side authorization on every request.** Client-supplied role/scope assertions never trusted.
- **Fail closed.** No error/exception/timeout skips an authorization check, bypasses a control, advances a workflow, or releases a payment. Every failure path is specified and tested.
- **Every `frappe.db.sql()` in a custom app applies scope conditions.** Reviewer signs that it does. Flagged automatically; reviewed manually. This is the compensating control for not having database-enforced RLS (`PG-2`).
- **`@frappe.whitelist()` with no permission check is a review rejection.**
- **No secret in code, config, env var, log, or error message.** Enforced by gitleaks in pre-commit and CI.
- **Errors state what happened, why, and what to do next.** Never a bare code, stack trace, path, query, version, or configuration.

### Concurrency & Integration
- **State-changing API requests require `If-Match`.** Mismatch returns `412 Precondition Failed`.
- **Non-idempotent financial commands accept a client idempotency key** with request parameter fingerprint. Same key + matching fingerprint replays stored response byte-identically. Same key + differing fingerprint = conflict.
- **Outbound integration uses transactional outbox.** Message and business state change commit in one MariaDB transaction. Two-phase commit is not used.
- **Every queue has a max delivery count and dead-letter queue.** DLQ arrival raises an operational alert.

### Configuration as Code (SR-2)
Every DocType, workflow, role, and custom field is exported to versioned JSON fixtures via `bench export-fixtures`. The repo is the source of truth — a build whose database configuration differs from the repo fails (fixture-drift check in CI).

## Pipeline (from `03-03`)

```
S1 STATIC (~2 min) → S2 UNIT (~10 min) → S3 BUILD (~5 min) → S4 INTEGRATION (~25 min) → S5 UI CRITICAL PATH (~20 min) → S6 SECURITY (~15 min)
```

Pipeline-enforced (not review-enforced):
- Core-fork check: build fails on any diff under `apps/frappe` or `apps/erpnext`
- Fixture-drift check: DB config must match repo fixtures
- Raw-SQL scope check: every `frappe.db.sql()` in custom apps must be flagged for signed review
- Money-as-string: contract test on every API response — no monetary value as JSON number
- gitleaks secret scan (also in pre-commit)
- Dependency vulnerability scan, SBOM generation

## Documentation Map

| Directory | Contains | Key Files |
|---|---|---|
| `documents/Primary-doc/` | Requirements (PRD, BRD, URD, SRS), platform decision, tech stack | `IMPLEMENTATION-OPTIONS.md`, `TECHNOLOGY-STACK.md` |
| `documents/project-document/` | Delivery layer — 42 docs across governance, architecture, engineering, data, test, transition, compliance, audit | `00-04` (open items), `01-01` (architecture), `03-01` (standards), `03-04` (WBS) |
| `documents/roadmap/` | 15-phase execution plan | `PROJECT-IMPLEMENTATION-ROADMAP.md` |
| `documents/Research/` | Master Functional Spec (~191K words, sections A–H) | `sections/MASTER-FUNCTIONAL-SPECIFICATION.md` |
| `documents/Research/sections/` | Detailed per-domain specs | `section-B-procurement.md`, `section-C-receive-to-pay.md`, etc. |

> **Phase numbering — three schemes, do not mix them.** Git commits and the roadmap use **roadmap phases 1–15** (`documents/roadmap/PROJECT-IMPLEMENTATION-ROADMAP.md`). The WBS (`03-04` §5) uses **build phases 0–5**. The user-stories module table (`documents/USER-STORIES.md`) uses a **5-phase priority scheme**. Numbers do not correspond across schemes: e.g. roadmap **Phase 4 = framework apps** (`sjibl_core`, `sjibl_bn`, `sjibl_doa`), whereas WBS **build phase 4 = roadmap Phase 10** (Asset · Contract · Shariah → `sjibl_shariah`).

## Module Reference (21 modules, M01–M21)

| # | Module | Priority | Build |
|---|---|---|---|
| M01 | Core Platform (RBAC, workflow, audit, master data) | P0 | L4 custom |
| M02 | Requisition Management | P0 | L1 config |
| M03 | e-Procurement / e-Tendering | P0 | L1 + L4 |
| M04 | Vendor Enlistment Portal | P0 | L1 config |
| M05 | Bid Submission Portal (vendor-facing) | P0 | L4 (85% custom) |
| M06 | Purchase Order Management | P0 | L1 config |
| M07 | Inventory & Warehouse | P0 | L1 + L4 |
| M08 | Invoicing, Budget, Tax, Payment | P0 | L1 + L3 + L4 |
| M09 | Contract Management | P1 | L1 + L4 |
| M10 | Asset, Repair & Maintenance | P1 | L1 config |
| M11 | e-Auction (asset disposal) | P1 | L4 (90% custom) |
| M12–M19 | Facilities (dispatch, building, civil, transport, insurance, medical, visitor, canteen) | P1–P2 | Low-code |
| M20 | Reporting & Analytics | P0 | L1/L2 config |
| M21 | Shariah Governance | P0 | L4 (80% custom) |

M17 (Medical) and M18 (Visitor) are architecturally isolated — separate encryption keys, no integration with procurement modules, DPIA-gated before build.
